import React from "react";
import { Box, Flex, Text, Button, Image } from "@chakra-ui/react";

const BannerMarketplace = () => {
  return (
    <Box
      bg="#242222"
      color="#FFFFFF"
      width="1024px"
      height="500px"
      display="flex"
      justifyContent="space-between"
      alignItems="center"
      paddingX="50px"
    >
      <Box>
        <Text fontSize="22px" color="#737373" textAlign="left">
          Trade your NTFs freely on
        </Text>
        <Text fontSize="38px" textAlign="left" mt="10px">
          Mushroom Protocol Marketplace
        </Text>
        <Button
          colorScheme="teal"
          backgroundColor="#1FAFC8"
          variant="solid"
          mt="20px"
          borderRadius="full"
        >
          View All
        </Button>
      </Box>
      <Image
        src="https://mushroomprotocol.io/wp-content/uploads/2023/03/26.png"
        alt="Mushroom Protocol"
        width="400px"
        height="400px"
      />
    </Box>
  );
};

export default BannerMarketplace;
