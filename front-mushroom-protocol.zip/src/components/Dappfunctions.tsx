import React from "react";
import { Box, Flex, Text } from "@chakra-ui/react";

const badgeStyle = {
  backgroundColor: "#1FAFC8", // Color de fondo celeste
  color: "#FFFFFF", // Color de letras blancas
  fontSize: "18px", // Tamaño de letra 18
  padding: "5px 10px",
  borderRadius: "10px",
  marginLeft: "10px"
};

const Dappfunctions = () => {
  return (
    <Flex
      bg="#242222"
      color="#FFFFFF"
      flexDirection="column"
      alignItems="center"
      width="1024px"
      height="400px"
      position="relative"
    >
      <Text fontSize="36px" mt="20px">
        Dapp functions
      </Text>

      <Box position="absolute" left="40px" top="100px">
        <Text fontSize="25px">Launchpad NFT</Text>
        <Text color="#737373" fontSize="22px">
          Mint NFTs based in R&D and finance biotechnology
        </Text>
      </Box>

      <Box position="absolute" left="40px" top="200px">
        <Text fontSize="25px">Marketplace NFT</Text>
        <Text color="#737373" fontSize="22px">
          Trade your NFTs in a decentralized way
        </Text>
      </Box>

      <Box position="absolute" left="40px" top="300px">
        <Text fontSize="25px">FungiDAO</Text>
        <Text color="#737373" fontSize="22px">
          Vote and participate <br />
          in the development of Mushroom Protocol
        </Text>
      </Box>

      <Box position="absolute" right="100px" top="175px">
        <Text fontSize="25px">
          Staking <span style={badgeStyle}>Coming Soon</span>
        </Text>
        <Text color="#737373" fontSize="22px">
          Lock your NFTs and earn rewards
        </Text>
      </Box>

      <Box position="absolute" right="45px" top="275px">
        <Text fontSize="25px">
          Vaults <span style={badgeStyle}>Coming Soon</span>
        </Text>
        <Text color="#737373" fontSize="22px">
          Store your NFTs safely and earn profits
        </Text>
      </Box>
    </Flex>
  );
};

export default Dappfunctions;
