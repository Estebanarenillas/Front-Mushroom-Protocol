import React from "react";
import { Box, Flex, Text, Button, Image } from "@chakra-ui/react";

const BannerFungiDAO = () => {
  return (
    <Box
      bg="#242222"
      color="#FFFFFF"
      width="1024px"
      height="500px"
      display="flex"
      justifyContent="space-between"
      alignItems="center"
      paddingX="50px"
    >
      <Box>
        <Text fontSize="22px" color="#737373" textAlign="left">
          Participates in the development of the protocol and decentralized
          sciences in
        </Text>
        <Text fontSize="38px" textAlign="left" mt="10px">
          Mushroom Protocol FungiDAO
        </Text>
        <Button
          colorScheme="teal"
          backgroundColor="#1FAFC8"
          variant="solid"
          mt="20px"
          borderRadius="full"
        >
          Proposals
        </Button>
      </Box>
      <Image
        src="https://mushroomprotocol.io/wp-content/uploads/2023/03/24.png"
        alt="Mushroom Protocol"
        width="450px"
        height="450px"
      />
    </Box>
  );
};

export default BannerFungiDAO;
