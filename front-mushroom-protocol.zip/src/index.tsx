import { ChakraProvider, Heading } from "@chakra-ui/react";
import * as React from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";
import Banner from "./components/Home/Banner";
import Dappfunctions from "./components/Home/Dappfunctions";
import FundedProjects from "./components/Home/FundedProjects";
import DeSciEcosystem from "./components/Home/DeSciEcosystem";
import JoinDiscord from "./components/JoinDiscord";
import BannerLaunchpad from "./components/Launchpad/BannerLaunchpad";
import BannerMarketplace from "./components/BannerMarketplace";
import BannerFungiDAO from "./components/BannerFungiDAO";
import LaunchpadNFT from "./components/Launchpad/LaunchpadNFT";
import NatheraPage from "./components/Launchpad/NatheraPage";
import NatheraDetails from "./components/Launchpad/NatheraDetails";
import FoundersPage from "./components/Launchpad/FoundersPage";
import FoundersDetails from "./components/Launchpad/FoundersDetails";

function App() {
  return <Heading>Welcome to Chakra + TS</Heading>;
}

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <React.StrictMode>
    <ChakraProvider>
      <App />
      <NatheraPage />
      <NatheraDetails />
      <FoundersPage />
      <FoundersDetails />
      <Banner />
      <FundedProjects />
      <Dappfunctions />
      <DeSciEcosystem />
      <JoinDiscord />
      <BannerLaunchpad />
      <LaunchpadNFT />
      <BannerMarketplace />
      <BannerFungiDAO />
    </ChakraProvider>
  </React.StrictMode>
);
